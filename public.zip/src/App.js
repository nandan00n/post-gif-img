import './App.css';
// import Dummy from './components/dummy';
// import Gif from './components/gif/Gif';
import Post from './components/Post';

function App() {
  return (
    <div className="App">
    <Post currentUserId="1"/>
      {/* <Gif/> */}
      {/* <Dummy/> */}
    </div>
  );
}

export default App;
